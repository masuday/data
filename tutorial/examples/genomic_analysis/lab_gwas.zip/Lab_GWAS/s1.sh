#!/bin/bash

#
# Example from Wang et al 2012 Gen Res 
#  to run scenario I for GWAS
#  one BLUP and iterate using different G
#

# uncomment next line and modify to match to your binary path
dir='../../bin'


# S1: 
mkdir S1
cd S1
sed  's:ren:../ren:g' ../par.b90     | sed  's:marker:../marker:g' > par.b90
sed  's:ren:../ren:g' ../postpar.b90 | sed  's:marker:../marker:g' > postpar.b90

awk 'BEGIN { for (i==1;i<3000;i++) print 1}'> w
echo par.b90 | $dir/blupf90 | tee log.blupf90
# run x times PreGSf90 . postGSf90 to get SNPeff:
for i in 1 2 3 #4 5 6 7 8  ... x
    do
     echo par.b90 | $dir/preGSf90 | tee log_preGS_$i
     echo postpar.b90  | $dir/postGSf90 | tee logpost_$i
       cp snp_sol snp_sol_$i
       # format: tr, eff, snpID, chr, pos, sol, weight
       cp chrsnp  chrsnp_$i
       cp w w_$i
     awk '{ print $7 }' snp_sol >  w
done
cd ..


