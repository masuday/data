#!/bin/bash

#
# Prepare and renum data to run 
#   GWAS example from GWAS from Wang et al 2012 Gen Res
#

# uncomment next line and modify to match to your binary path
dir='../bin'
echo renum.par | $dir/renumf90 | tee log.renum

cp renf90.par par.b90
cp renf90.par postpar.b90

echo "OPTION saveGInverse" >> par.b90
echo "OPTION weightedG w" >> par.b90

echo "OPTION weightedG w" >> postpar.b90
echo "OPTION ReadGInverse" >> postpar.b90
echo "OPTION chrinfo ../chrmap" >> postpar.b90
echo "#OPTION which_weight 1" >> postpar.b90
echo "#OPTION windows_variance 4" >> postpar.b90
echo "OPTION Manhattan_plot" >> postpar.b90

