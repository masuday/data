#!/bin/bash

#
# Example from Wang et al 2012 Gen Res 
#  to run scenario II for GWAS
#  run BLUP in each iteration
#

# uncomment next line and modify to match to your binary path
#dir="../../bin/"

mkdir S2
cd S2

sed  's:ren:../ren:g' ../par.b90     | sed  's:marker:../marker:g' > par.b90
sed  's:ren:../ren:g' ../postpar.b90 | sed  's:marker:../marker:g' > postpar.b90

awk 'BEGIN { for (i==1;i<3000;i++) print 1}'>  w
for i in 1 2 3 #4 5 6 7 8 ... x
    do
      echo par.b90 | $(dir)blupf90 | tee logpre_$i
      cp solutions solutions_$i
      echo postpar.b90  | $(dir)postGSf90 | tee logpost_$i
      cp snp_sol snp_sol_$i
      cp chrsnp  chrsnp_$i
      cp w w_$i
      awk '{ print $7}' snp_sol>  w
  done
cd ..
