#!/bin/bash

#
# Prepare and renum data to run 
#   GWAS example from GWAS from Wang et al 2012 Gen Res
#   Simplified by Yutaka Masuda
#

# your binary path (ending with /)
bindir='./'

echo renum.par | ${bindir}renumf90 | tee log.renum

# making parameter files
cp renf90.par param_ssgwas1a.txt
cp renf90.par param_ssgwas1b.txt

# adding extra options
# BLUPF90
echo "OPTION saveGInverse" >> param_ssgwas1a.txt
echo "OPTION weightedG w" >> param_ssgwas1a.txt

# POSTGSF90
echo "OPTION ReadGInverse" >> param_ssgwas1b.txt
echo "OPTION weightedG w" >> param_ssgwas1b.txt
echo "OPTION chrinfo chrmap.txt" >> param_ssgwas1b.txt
echo "#OPTION Manhattan_plot" >> param_ssgwas1b.txt
