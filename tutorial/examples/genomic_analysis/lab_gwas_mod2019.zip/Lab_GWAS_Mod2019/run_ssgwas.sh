#!/bin/bash

#
# Example from Wang et al 2012 Gen Res 
# Similar to s2.sh in the original package.
# Modified by Yutaka Masuda
#
# This script changes the file `w`. The default file
# (with all 1s) will be created as `w.default`.
#

# your binary path (ending with /)
bindir='./'

# result directory
resdir=results
mkdir -p ${resdir}

# the number of iteration
niter=2

#
# You don't have to modify the following statements unless needed.
#

# the number of snps
ns=`wc -l chrmap | awk '{print $1}'`

# the default weights
awk -v ns=${ns} 'BEGIN {for(i=1;i<=ns;i++) print 1}' > w
cp w w.default

for i in `seq 1 ${niter}`; do
   # updating the weights using BLUPF90 and POSTGSF90
   echo param_ssgwas1a.txt | ${dir}blupf90 | tee logblup_$i
   cp solutions solutions_$i
   echo param_ssgwas1b.txt | ${dir}postGSf90 | tee logpost_$i
   cp snp_sol snp_sol_$i
   cp chrsnp chrsnp_$i
   cp w w_$i
   awk '{print $7}' snp_sol > w

   # save the results in the current iteration
   mv logblup_$i $resdir
   mv logpost_$i $resdir
   mv solutions_$i $resdir
   mv snp_sol_$i $resdir
   mv chrsnp_$i $resdir
   mv w_$i $resdir
done
